package auto.utilities;

import auto.model.Auto;
import auto.model.Boot;
import auto.model.MotorBoot;
import auto.model.StootKar;
import auto.model.Voertuig;
import auto.model.Vrachtwagen;

/**
 * Write a description of class Factory here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Factory
{


    /**
     * An example of a factorymethod
     * 
     * @param  y   int
     * @return     Voertuig 
     */
    public static Voertuig createVoertuig(int y)
    {
        // put your code here
        switch(y){
            case 0: return new StootKar();
            case 1: return new Auto();
            case 2: return new Vrachtwagen();
            
            case 3: return new Boot();
            case 4: return new MotorBoot();
            default:return null;
        }
    }
    }
