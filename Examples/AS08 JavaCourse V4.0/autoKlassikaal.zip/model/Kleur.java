package auto.model;
/**
 * Write a description of class Kleur here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Kleur
{
    // instance variables - replace the example below with your own

    public static final int WIT = 0;
    public static final int GROEN = 1;
    public static final int ROOD = 2;
    public static final int BLAUW = 3;
    public static final int GEEL = 4;   

    /**
     * Constructor for objects of class Kleur
     */
    public Kleur()
    {
        // initialise instance variables

    }

    /**
     * This method generates a random Color
     * @return     a color
     */
    public static int randomKleur()
    {
        // put your code here
        return (int)(Math.random()*5.0);
    }

    /**
     * This method gives a color
     * @return     a color
     */ 
    public static String getKleur(int i){
        switch(i){
            case WIT: return "Wit";
            case GROEN: return "Groen";
            case ROOD: return "Rood";
            case BLAUW: return "Blauw";         
            case GEEL: return "Geel";            
            default: return "Onbekende kleur";
        }
    }
}
