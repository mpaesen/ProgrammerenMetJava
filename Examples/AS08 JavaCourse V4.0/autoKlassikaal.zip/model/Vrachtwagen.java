package auto.model;
/**
 * Write a description of class Vrachtwagen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Vrachtwagen extends Auto
{
    // instance variables - replace the example below with your own
    private String laadbak;

    /**
     * Constructor for objects of class Vrachtwagen
     */
    public Vrachtwagen()
    {
        // initialise instance variables
        switch((int)(Math.random()*3.0)){
            case 0:laadbak = "open container";break;
            case 1:laadbak = "tank";break;
            case 2:laadbak = "gesloten container";break;            
            default:laadbak = "geen laadbak";break;
        }
    }

    /**
     * An example of a set method
     * 
     * @param  laadbak String
     */
    public void setLaadBak(String laadbak)
    {
        // put your code here
        this.laadbak = laadbak;
    }
        /**
     * An example of a set method
     * 
     * @return  laadbak 
     */
    public String getLaadBak()
    {
        // put your code here
        return this.laadbak;
    }
    
    public String toString(){
        return super.toString()+"\n\thet is een vrachtwagen met als laadbak: "+getLaadBak();
    }
 }
