package auto.model;
/**
 * Abstract class Voertuig - write a description of the class here
 * 
 * @author: Mathy 
 * Date: 21/09/2003
 */
public abstract class Voertuig
{

    /**
     * An example of an abstract method
     * 
     * @return      String
     */
    public abstract String toString();
}
