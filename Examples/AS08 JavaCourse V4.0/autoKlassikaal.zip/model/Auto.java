package auto.model;


/**
 * Write a description of class Auto here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Auto extends Voertuig
{
    // instance variables - replace the example below with your own
    private Motor motor;
    private int kleur;
    private Venster vensters[] = {new Venster("voor"),new Venster("achter")};
    private Deur deuren[] =  {new Deur("links voor"),new Deur("rechts voor"),new Deur("links achter"),new Deur("rechts achter")};
    private Wiel wielen[] =  {new Wiel(),new Wiel(),new Wiel(),new Wiel()};;

    /**
     * Constructor for objects of class Auto
     */
    public Auto()
    {
        // initialise instance variables
        motor = new Motor();
        kleur = Kleur.randomKleur();
    }
   /**
     * Gives the Motor
     * 
     * @return     the motor
     */
    public Motor getMotor()
    {
        // put your code here
        return motor;
    }
    public String getKleur()
    {    
        return Kleur.getKleur(this.kleur);
    }
    /**
     * Gives a Window
     * 
     * @param  y   index in array deuren
     * @return     the selected Door
     */
    /**
     * Gives a selected Wheel
     * 
     * @param  y   index in array wielen
     * @return     the selected Wheel
     */
    public Wiel getWiel(int y)
    {
        // put your code here
        return wielen[y];
    }    
    public Venster getVenster(int y)
    {
        // put your code here
        return vensters[y];
    }
    
    /**
     * Gives a Door
     * 
     * @param  y   index in array deuren
     * @return     the selected Door
     */
    public Deur getDeur(int y)
    {
        // put your code here
        return deuren[y];
    }
  
   /**
     * Gives all doors
     * 
     * @param  y   index in array wielen
     * @return     the selected Wheel
     */
    public String getDeuren()
    {
        // put your code here
        StringBuffer str = new StringBuffer();
        str.append("[");
        for(int i=0; i<deuren.length; i++){
            str.append(getDeur(i));
             if(i<deuren.length-1)
                str.append(", ");
        }
        str.append("]");
        return str.toString();
            
    }    
  /**
     * Gives all windows
     * 
     * @param  y   index in array wielen
     * @return     the selected Wheel
     */
    public String getVensters()
    {
        // put your code here
        StringBuffer str = new StringBuffer();
        str.append("[");
        for(int i=0; i<vensters.length; i++){
            str.append(getVenster(i));
            if(i<vensters.length-1)
                str.append(", ");
        }
        str.append("]");
        return str.toString();
            
    }            
      /**
     * Gives all wheels
     * 
     * @param  y   index in array wielen
     * @return     the selected Wheel
     */
    public String getWielen()
    {
        // put your code here
        StringBuffer str = new StringBuffer();
        str.append("[");
        for(int i=0; i<wielen.length; i++){
            str.append(getWiel(i));
             if(i<wielen.length-1)
                str.append(", ");
        }        
        str.append("]");
        return str.toString();
            
    }        
       /**
     * String value of a Car
     * 
     * @return     String value of this motor
     */        
    public String toString(){
        return "Deze auto heeft een "+getMotor()+"motor \n\tde deuren zijn: "+getDeuren() +"\n\tde wielen zijn: "+ getWielen()+ "\n\tmet als vensters: "+ getVensters()+"\n\ten als kleur: "+ getKleur();
    }        
}
