package auto.model;
/**
 * Write a description of class Wiel here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Wiel
{
    // instance variables - replace the example below with your own
    static int nummer = 0;
    private String wiel;

    /**
     * Constructor for objects of class Wiel
     */
    public Wiel()
    {
        // initialise instance variables
        nummer++;
        wiel = "Wiel "+nummer;
    }
   /**
     * String value of a wheel
     * 
     * @return     String value of this motor
     */        
    public String toString(){
        return wiel;
    }    
}
