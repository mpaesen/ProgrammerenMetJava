package auto.model;
/**
 * Write a description of class StootKar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StootKar extends Voertuig
{
    public String toString(){
        return "Dit voertuig is een stootkar.";
        
    }
}
