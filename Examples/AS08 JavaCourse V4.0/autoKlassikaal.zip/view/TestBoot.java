package auto.view;

import auto.model.Boot;

public class TestBoot {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Boot boot = new Boot();
		System.out.print(boot);

	}

}
