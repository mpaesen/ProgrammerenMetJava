package auto.view;

import auto.model.Auto;

/**
 * Write a description of class TestAuto here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TestAuto
{
	/**
	 * An example of a main method
	 * 
	 */
	public static void main(String args[])
	{
		// put your code here
		System.out.println(new Auto());
	}
}
