package auto.view;

import auto.model.Voertuig;
import auto.utilities.Factory;


/**
 * Write a description of class TestVoertuig here.
 * 
 * @author (Mathy Paesen) 
 * @version (21/09/2003)
 */
public class TestVoertuig
{

    private Voertuig[] voertuigen;


	protected void setUp() {
	    voertuigen = new Voertuig[20];
	    for(int i=0; i<voertuigen.length; i++){
	           voertuigen[i] = Factory.createVoertuig((int)(Math.random()*5.0));
	    }
	}
 

    public void print() {
	    for(int i=0; i<voertuigen.length; i++)
	           System.out.println("\nVoertuig "+i+": "+voertuigen[i]);    
	}

      public static void main(String[] args) {
		TestVoertuig voertuig = new TestVoertuig();
		voertuig.setUp();
		voertuig.print();
	}
}