package boatrescue;

/**
 * Write a description of class Coördinaten here.
 * 
 * @author Mathy Paesen
 * @version 1.0
 */
public class Coördinaten
{
	// instance variables - replace the example below with your own
	private final double breedte;
	private final double lengte;

	/**
	 * Constructor for objects of class Coördinaten
	 */
	public Coördinaten(final double breedte, final double lengte)
	{
		// initialise instance variables
		this.lengte = lengte;
		this.breedte = breedte;
	}

	public double getBreedte()
	{
		// put your code here
		return breedte;
	}

	public double getLengte()
	{
		// put your code here
		return lengte;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString()

	{
		final StringBuilder builder = new StringBuilder();
		builder.append("getBreedte()=" + String.format("%2.3f", getBreedte()));
		builder.append(", getLengte()=" + String.format("%2.3f", getLengte()));
		return "Coördinaten [" + builder + "]";
	}

	public boolean equals(final Coördinaten coördinaten)
	{
		if (this.breedte == coördinaten.getBreedte() && this.lengte == coördinaten.getLengte())
		{
			return true;
		}
		return false;

	}
}
