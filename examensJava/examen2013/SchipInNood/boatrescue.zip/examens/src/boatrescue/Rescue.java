package boatrescue;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Random;

/**
 * Test basis functionaliteiten Schip in Nood
 * 
 * @author Mathy Paesen 
 * @version 20/11/2016
 */
public class Rescue
{
	private static List<Actor> verkeerstorens;
	private static List<Actor> hulpdiensten;
	private static List<Actor> schepen;
	private static Random random = new Random();
	private static Locatie locatie;

	public static void main(final String[] args)
	{
		verkeerstorens = randomVerkeerstorens();
		hulpdiensten = randomHulpdiensten(verkeerstorens);
		schepen = randomSchepen(verkeerstorens);
		final Schip schipInNood = (Schip) schepen.get(random.nextInt(Math.abs(schepen.size())));
		final Verkeerstoren controle = schipInNood.getVerkeerstoren();

		printActors(schepen, "Schepen");
		printActors(verkeerstorens, "Verkeerstorens");
		printActors(hulpdiensten, "Hulpdiensten");
		controle.notifyObservers(schipInNood);
	}

	public static List<Actor> randomVerkeerstorens()
	{
		final List<Actor> list = new ArrayList<Actor>();

		for (int i = 0; i < random.nextInt(IGeneralStrategy.AANTAL); i++)
		{
			locatie = GeneralStrategyFactory.createLocatie(random);
			list.add(ActorFactory.createActor(1, locatie));
		}
		return list;
	}

	public static List<Actor> randomSchepen(final List<Actor> verkeerstorens)
	{
		final List<Actor> list = new ArrayList<Actor>();
		final ListIterator<Actor> it = verkeerstorens.listIterator();
		Verkeerstoren verkeerstoren;
		Schip schip;
		final int aantalSchepen = random.nextInt(IGeneralStrategy.AANTAL);

		while (it.hasNext())
		{
			verkeerstoren = (Verkeerstoren) it.next();
			for (int i = 0; i < aantalSchepen; i++)
			{
				locatie = GeneralStrategyFactory.createLocatie(random);
				schip = (Schip) ActorFactory.createActor(2, locatie);
				schip.setVerkeerstoren(verkeerstoren);
				list.add(schip);
			}
		}
		return list;
	}

	public static List<Actor> randomHulpdiensten(final List<Actor> verkeerstorens)
	{
		final List<Actor> list = new ArrayList<Actor>();
		final ListIterator<Actor> it = verkeerstorens.listIterator();
		Verkeerstoren verkeerstoren;
		Hulpdienst hulpdienst;
		final int aantalHulpdiensten = random.nextInt(IGeneralStrategy.AANTAL);

		while (it.hasNext())
		{
			verkeerstoren = (Verkeerstoren) it.next();

			for (int i = 0; i < aantalHulpdiensten; i++)
			{
				locatie = GeneralStrategyFactory.createLocatie(random);
				hulpdienst = (Hulpdienst) ActorFactory.createActor(3, locatie);
				hulpdienst.setVerkeerstoren(verkeerstoren);
				list.add(hulpdienst);
			}
		}
		return list;
	}

	public static void printActors(final List<Actor> list, final String title)
	{
		System.out.println("list of: " + title);
		final ListIterator<Actor> it = list.listIterator();
		while (it.hasNext())
		{
			System.out.println(it.next());
		}
	}
}