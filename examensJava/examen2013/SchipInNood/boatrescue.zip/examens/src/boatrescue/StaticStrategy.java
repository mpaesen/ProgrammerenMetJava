package boatrescue;

/**
 * Write a description of class StaticStrategy here.
 * 
 * @author Mathy Paesen
 * @version 1.0
 */

public class StaticStrategy implements IGeneralStrategy
{
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString()
	{
		final StringBuilder builder = new StringBuilder();
		builder.append(" getReactieTijd()=" + getReactieTijd());
		return "StaticStrategy  [ " + builder + "]";
	}

	public double getSnelheid()
	{
		return 0.0;
	}

	public double getReactieTijd()
	{
		return 0.0;
	}

	public double getWendbaarheid(final double graden)
	{
		return 0.0;
	}

	public double getGrootte()
	{
		return 0.0;
	}

	public int getCapaciteit()
	{
		return 0;
	}

	public double getKoers()
	{
		return 0.0;
	}
}
