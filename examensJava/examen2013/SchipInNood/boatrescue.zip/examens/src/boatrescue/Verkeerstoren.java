package boatrescue;

import java.util.ArrayList;
import java.util.List;

/**
 * Write a description of class Verkeerstoren here.
 * 
 * @author Mathy Paesen
 * @version 1.0
 */
public class Verkeerstoren extends Actor implements ISubject
{
	private final List<Schip> schepenOnderKontrole;
	private final List<Hulpdienst> hulpDiensten;

	public Verkeerstoren(final Locatie locatie)
	{
		super(locatie);
		schepenOnderKontrole = new ArrayList<Schip>();
		hulpDiensten = new ArrayList<Hulpdienst>();
	}

	public void registerObserver(final Schip schip)
	{
		schepenOnderKontrole.add(schip);
	}

	public void registerObserver(final Hulpdienst hulpdienst)
	{
		hulpDiensten.add(hulpdienst);
	}

	public void removeObserver(final Schip schip)
	{
		schepenOnderKontrole.remove(schip);
	}

	public void notifyObservers(final Schip schipInNood)
	{
		System.out.printf("%s", "\nSchip in nood, coördinaten :" + schipInNood.getLocatie());
		for (final Schip schip : schepenOnderKontrole)
		{
			if (schip.isGeschikt(schipInNood))
			{
				sendSchip(schip, schipInNood);
				schip.updateObserver(schipInNood);
			}
		}
		for (final Hulpdienst hulpdienst : hulpDiensten)
		{
			System.out.printf("%s", "\n" + hulpdienst + " gestuurd naar schip in nood!");
			hulpdienst.updateObserver(schipInNood);

		}
	}

	public void updateSchipLocatie(final Schip schip)
	{
		schepenOnderKontrole.set(schepenOnderKontrole.indexOf(schip), schip);
	}

	private void sendSchip(final Schip schip, final Schip schipInNood)
	{
		schip.setKoers(schipInNood.getFuncties().getKoers());
		System.out.printf("%s", "\n" + schip + " is geschikt en gestuurd naar schip in nood!");
	}

	private List<Schip> getSchepenOnderKontrole()
	{
		return schepenOnderKontrole;
	}

	private List<Hulpdienst> getHulpDiensten()
	{
		return hulpDiensten;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString()

	{
		return "Verkeerstoren : " + super.toString();
	}
}
