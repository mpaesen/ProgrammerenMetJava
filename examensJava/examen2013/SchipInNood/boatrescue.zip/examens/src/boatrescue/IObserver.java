package boatrescue;

/**
 * Write a description of interface IObserver here.
 * 
 * @author Mathy Paesen
 * @version 1.0
 */

public interface IObserver
{
	public void updateObserver(Schip schipInNood);

}
