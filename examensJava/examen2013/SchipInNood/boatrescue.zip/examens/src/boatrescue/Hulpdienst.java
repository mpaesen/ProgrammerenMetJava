package boatrescue;

/**
 * Write a description of class Helicopter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Hulpdienst extends Actor implements IObserver
{
	private Locatie bestemming;
	private Verkeerstoren verkeerstoren;

	public Hulpdienst(final Locatie locatie)
	{
		super(locatie);
	}

	/**
	 * @param locatie
	 * @param bestemming
	 * @param verkeerstoren
	 */
	public Hulpdienst(final Locatie locatie, final Verkeerstoren verkeerstoren)
	{
		super(locatie);
		this.verkeerstoren = verkeerstoren;
	}

	public void setVerkeerstoren(final Verkeerstoren verkeerstoren)
	{
		this.verkeerstoren = verkeerstoren;
		verkeerstoren.registerObserver(this);
	}

	/**
	 * @return the verkeerstoren
	 */
	public Verkeerstoren getVerkeerstoren()
	{
		return verkeerstoren;
	}

	@Override
	public void updateObserver(final Schip schip)
	{
		//stuur locatie van schip in nood
		bestemming = schip.getLocatie();
		System.out.printf("%s", "\n\tKoers gewijzigd naar bestemming :" + bestemming);
	}

	@Override
	public String toString()
	{
		return "Hulpdienst met " + super.toString();
	}

	/**
	 * @return the bestemming
	 */
	public Locatie getBestemming()
	{
		return bestemming;
	}

	/**
	 * @param bestemming the bestemming to set
	 */
	public void setBestemming(final Locatie bestemming)
	{
		this.bestemming = bestemming;
	}

}
