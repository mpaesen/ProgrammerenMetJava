package boatrescue;

/**
 * Write a description of class Locatie here.
 * 
 * @author Mathy Paesen
 * @version 1.0
 */
public class Locatie
{
	private Coördinaten coördinaten;

	public Locatie(final Coördinaten coördinaten)
	{
		this.coördinaten = coördinaten;
	}

	public Coördinaten getLocatie()
	{
		return coördinaten;
	}

	public void setLocatie(final Coördinaten coördinaten)
	{
		this.coördinaten = coördinaten;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString()
	{
		return "Locatie [getLocatie()=" + getLocatie().toString() + "]";
	}

	public boolean equals(final Locatie locatie)
	{
		if (this.coördinaten.equals(locatie.getLocatie()))
		{
			return true;
		}
		return false;
	}
}
