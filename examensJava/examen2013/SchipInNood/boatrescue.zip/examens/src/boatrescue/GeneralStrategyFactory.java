package boatrescue;

import java.util.Random;

/**
 * Write a description of class GeneralStrategyFactory here.
 * 
 * @author Mathy Paesen
 * @version 1.0
 */
public class GeneralStrategyFactory
{

	public static IGeneralStrategy createBasisFuncties(final int type)
	{
		IGeneralStrategy functies = null;
		switch (type)
		{
		case 1:
		{
			functies = new StaticStrategy();
			break;
		}
		case 2:
		{
			functies = new MobileStrategy();
			break;
		}
		}
		return functies;
	}

	public static Locatie createLocatie(final Random random)
	{
		return new Locatie(new Coördinaten(random.nextDouble() * IGeneralStrategy.RECHT, random.nextDouble() * IGeneralStrategy.RECHT));

	}
}
