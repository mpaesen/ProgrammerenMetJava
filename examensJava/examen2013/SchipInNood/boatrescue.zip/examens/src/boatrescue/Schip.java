package boatrescue;

import java.util.Random;

/**
 * Write a description of class Schip here.
 * 
 * @author Mathy Paesen
 * @version 1.0
 */
public class Schip extends Actor implements IObserver
{
	private Verkeerstoren verkeerstoren;
	private double koers;
	private double snelheid;
	private int capaciteit;
	private double grootte;
	private Locatie bestemming;
	private Bericht laatsteBericht;

	/**
	 * Constructor for objects of class Schip
	 */
	public Schip(final Locatie locatie)
	{
		super(locatie);
		bestemming = GeneralStrategyFactory.createLocatie(new Random());
	}

	public Schip(final Locatie locatie, final Locatie bestemming)
	{
		super(locatie);
		this.bestemming = bestemming;
	}

	@Override
	public void updateObserver(final Schip schip)
	{
		//stuur locatie van schip in nood
		bestemming = schip.getLocatie();
		System.out.printf("%s", "\n\tKoers gewijzigd naar bestemming :" + bestemming);
	}

	public void setSnelheid(final double snelheid)
	{
		this.snelheid = snelheid;
	}

	public void setGrootte(final double grootte)
	{
		this.grootte = grootte;
	}

	public void setCapaciteit(final int capaciteit)
	{
		this.capaciteit = capaciteit;
	}

	public void setKoers(final double koers)
	{
		this.koers = koers;
	}

	public void stuurBericht()
	{
		//meld locatie en koers aan verkeerstoren om de 10'
		setLaatsteBericht();
		verkeerstoren.updateSchipLocatie(this);
		System.out.printf("%s", "\nBericht verzonden");
	}

	public Verkeerstoren getVerkeerstoren()
	{
		return verkeerstoren;
	}

	public void setVerkeerstoren(final Verkeerstoren verkeerstoren)
	{
		this.verkeerstoren = verkeerstoren;
		verkeerstoren.registerObserver(this);
	}

	private void setLaatsteBericht()
	{
		laatsteBericht = new Bericht(this.getLocatie(), this.getFuncties().getKoers());

	}

	public void help()
	{
		setLaatsteBericht();
		laatsteBericht.sendSOS();
	}

	public boolean isGeschikt(final Schip schipInNood)
	{
		//test of schip voldoet om hulp te bieden
		//op basis van capaciteit, afstand, grootte en reactietijd
		if (this.equals(schipInNood))
		{
			return false;
		}

		if (this.getFuncties().getCapaciteit() >= schipInNood.getFuncties().getCapaciteit())
		{
			return true;
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */

	public boolean equals(final Schip schip)
	{
		if (this.getLocatie().equals(schip.getLocatie()))
		{
			return true;
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString()
	{
		return "Schip met " + super.toString();
	}

}