package boatrescue;

/**
 * Write a description of class MobileStrategy here.
 * 
 * @author Mathy Paesen
 * @version 1.0
 */
public class MobileStrategy implements IGeneralStrategy
{
	/* (non-Javadoc)
	* @see java.lang.Object#toString()
	*/
	@Override
	public String toString()
	{
		final StringBuilder builder = new StringBuilder();
		builder.append("getSnelheid()=" + String.format("%2.3f", getSnelheid()));
		builder.append(", getReactieTijd()=" + String.format("%2.3f", getReactieTijd()));
		builder.append(", getGrootte()=" + String.format("%2.3f", getGrootte()));
		builder.append(", getCapaciteit()=" + getCapaciteit());
		builder.append(", getKoers()=" + String.format("%2.3f", getKoers()));
		return "MobileStrategy [ " + builder.toString() + "]";
	}

	public double getSnelheid()
	{
		return 10 * Math.random();
	}

	public double getReactieTijd()
	{
		return 10 * Math.random();
	}

	public double getWendbaarheid(final double graden)
	{
		return graden * Math.random();
	}

	public double getGrootte()
	{
		return 100 * Math.random();
	}

	public int getCapaciteit()
	{
		return (int) (50 * Math.random());
	}

	public double getKoers()
	{
		return 10 * Math.random();
	}
}
