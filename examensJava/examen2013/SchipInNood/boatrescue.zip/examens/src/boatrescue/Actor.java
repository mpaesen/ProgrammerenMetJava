package boatrescue;

/**
 * Abstract class Actor - write a description of the class here
 * 
 * @author Mathy Paesen
 * @version 1.0
 */
public abstract class Actor
{
	// instance variables - replace the example below with your own
	private IGeneralStrategy functies;
	private final Locatie locatie;

	public Actor(final Locatie locatie)
	{
		this.locatie = locatie;
	}

	public void setFuncties(final IGeneralStrategy functies)
	{
		this.functies = functies;
	}

	public IGeneralStrategy getFuncties()
	{
		return functies;
	}

	public double getAfstand(final Actor actor)
	{
		return 1.0;
	}

	public Locatie getLocatie()
	{
		return locatie;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString()
	{
		final StringBuilder builder = new StringBuilder();
		builder.append(getFuncties());
		builder.append("," + getLocatie());
		return builder.toString();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */

}
