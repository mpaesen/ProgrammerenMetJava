package boatrescue;

/**
 * Write a description of interface IGeneralStrategy here.
 * 
 * @author Mathy Paesen
 * @version 1.0
 */
public interface IGeneralStrategy
{
	public double getSnelheid();

	public double getReactieTijd();

	public double getWendbaarheid(double graden);

	public double getGrootte();

	public int getCapaciteit();

	public double getKoers();
	public static final int AANTAL = 20;
	public static final double RECHT = 90.0;

}
