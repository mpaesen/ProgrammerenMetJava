package boatrescue;

/**
 * Write a description of class Bericht here.
 * 
 * @author Mathy Paesen
 * @version 1.0
 */
public class Bericht
{
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString()
	{
		return "SOS Bericht [getKoers()=" + getKoers() + ", getLocatie()=" + getLocatie() + "]";
	}
	private final Locatie locatie;
	private final double koers;

	public Bericht(final Locatie locatie, final double koers)
	{
		this.locatie = locatie;
		this.koers = koers;
	}

	public double getKoers()
	{
		return koers;
	}

	public Locatie getLocatie()
	{
		return locatie;
	}

	public void sendSOS()
	{
		System.out.printf("%s", "\nHelp we zinken!");
	}
}
