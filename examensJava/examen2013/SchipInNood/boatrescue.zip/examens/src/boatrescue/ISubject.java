package boatrescue;

/**
 * Write a description of interface ISubject here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface ISubject
{
    public void registerObserver(Schip schip);
    public void removeObserver(Schip schip);
    public void notifyObservers(Schip schipInNood);
}
